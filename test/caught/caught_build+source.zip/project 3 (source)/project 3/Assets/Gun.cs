﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gun : MonoBehaviour
{
    public float damage = 1;
    public bool automatic = false;
    public float fireRate = 0.1f;
    public float timeSinceLastShot;
    public uint ammo;
    public float bulletSpeed = 100;
    public Transform bulletSpawn;
    public bool obtained = false;
    public float spread = 1;

    // Update is called once per frame
    void Update ()
    {
		if (timeSinceLastShot > 0)
        { timeSinceLastShot -= Time.deltaTime; }
	}

    public virtual int Fire ()
    {
        if (timeSinceLastShot <= 0)
        {
            timeSinceLastShot = fireRate;
            if (ammo > 0)
            {
                ammo--;
                return 1;
            }
            return -1;
        }
        return 0;
    }
}
