﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bounce : MonoBehaviour
{
    Transform myTransform;
    public float rotationSpeed = 30;
    public float bounceSpeed;
    public float bounceMinHeight;
    public float bounceMaxHeight;

    float currentPosition;
    int bounceDirection = 1;

    void Start()
    { myTransform = gameObject.transform; }

    void Update()
    {
        currentPosition += bounceSpeed * bounceDirection * Time.deltaTime;
        if (currentPosition >= 1)
        {
            currentPosition = 1;
            bounceDirection = -1;
        }
        else if (currentPosition <= 0)
        {
            currentPosition = 0;
            bounceDirection = 1;
        }
        myTransform.position = new Vector3(myTransform.position.x, Mathf.SmoothStep(bounceMinHeight, bounceMaxHeight, currentPosition), myTransform.position.z);
        myTransform.Rotate(new Vector3(0, rotationSpeed * Time.deltaTime, 0));
    }
}
