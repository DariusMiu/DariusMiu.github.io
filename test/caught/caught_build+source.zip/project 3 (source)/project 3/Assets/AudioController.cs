﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class AudioController : MonoBehaviour
{
	public AudioSource source;
	public OptionsMenu options;
	public float loopDelay;
	public AudioClip[] clips;
	int currentlyPlaying;
    System.Random RAND = new System.Random();
	float loopTimer;

	void Start()
	{
		options.Load();
		source.volume = options.music;
	}

	void Update ()
	{
		if (!source.isPlaying)
		{
			loopTimer += Time.deltaTime;
			if (loopTimer >= loopDelay)
			{
				int next = currentlyPlaying;
				while (next == currentlyPlaying)
				{ next = RAND.Next(clips.Length); }
				currentlyPlaying = next;
				source.PlayOneShot(clips[next], 1);

				loopTimer = 0;
			}
		}
	}
}
