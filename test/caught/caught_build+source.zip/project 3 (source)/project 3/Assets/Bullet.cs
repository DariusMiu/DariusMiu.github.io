﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float damage;

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "enemy")
        { }
        if (other.gameObject.tag != "bullet" && other.gameObject.tag != "cleanup" && other.gameObject.name != "player")
        { Destroy(gameObject); }
    }
}
