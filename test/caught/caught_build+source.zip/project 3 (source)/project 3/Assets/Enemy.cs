﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.AI;

public class Enemy : MonoBehaviour
{
    protected Transform myTransform;
    protected Transform playerTransform;
    public Jenny jenny;
    public PlayerController player;
    public Rigidbody myBody;
    public float forceModifier = 10000;
    public Vector3 heading;
    public float health = 10;
    public float pointValue;
    public NavMeshAgent agent;

    void Start()
    {
        myTransform = gameObject.transform;
        playerTransform = GameObject.Find("player").transform;
        player = GameObject.Find("player").GetComponent(typeof(PlayerController)) as PlayerController;
        agent = GetComponent<NavMeshAgent>() as NavMeshAgent;
        jenny = GameObject.Find("world controller").GetComponent(typeof(Jenny)) as Jenny;
        if (jenny.wave <= 5)
        { agent.speed = 3.5f; }
        else if (jenny.wave <= 10)
        { agent.speed = 5f; }
        else //if (jenny.wave <= 25)
        { agent.speed = 6f; }
    }

    void Update ()
    {
        //heading = playerTransform.position - myTransform.position;
        //myBody.AddForce(heading.normalized * forceModifier * Time.deltaTime);
        agent.destination = playerTransform.position;
    }

    void OnTriggerEnter(Collider other)
    {
        //Debug.Log("enemy collided:" + other.gameObject.name);
        if (other.gameObject.tag == "bullet" && health > 0)
        {
            health -= (other.gameObject.GetComponent<Bullet>() as Bullet).damage;
            Destroy(other.gameObject);
            if (health <= 0)
            {
                player.Points += pointValue;
                jenny.currentEnemies--;
                if (jenny.currentEnemies <= 0)
                { jenny.NewWave(); }
                Destroy(gameObject);
            }
        }
    }
}
