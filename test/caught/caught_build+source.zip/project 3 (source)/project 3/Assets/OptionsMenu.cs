﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Xml;
using System;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;

[DataContract]
public class OptionsMenu : MonoBehaviour
{
    public GameObject mainMenu;
    public MainMenuButtons mainMenuButtons;
	public Text soundFXtext;
	public Slider soundFXslider;
	public Text musicText;
	public Slider musicSlider;
	[DataMember]
	public float soundFX = 0.5f;
	[DataMember]
	public float music = 0.5f;

	void Update()
	{
		soundFX = soundFXslider.value;
		soundFXtext.text = (soundFX * 100).ToString("0.0");
		music = musicSlider.value;
		musicText.text = (music * 100).ToString("0.0");
        mainMenuButtons.backgroundSource.volume = music;
	}

	public void BackToMain()
	{
		mainMenuButtons.BackToMain();
        mainMenuButtons.LoadSettings();
	}

	public void Load()
    {
        string filename = "settings.snep";
        Debug.Log("loading " + filename + "...");
        FileStream stream = new FileStream(filename, FileMode.Open);
        XmlDictionaryReader reader = XmlDictionaryReader.CreateTextReader(stream, new XmlDictionaryReaderQuotas());
        try
        {
            DataContractSerializer serializer = new DataContractSerializer(typeof(OptionsMenu));
            OptionsMenu options = (OptionsMenu)serializer.ReadObject(reader, true);
            soundFX = options.soundFX;
            music = options.music;
            Debug.Log("done.");
        }
        catch (Exception e)
        {
            Debug.Log("load failed. " + e.Message);
            Debug.Log("Stacktrace:\n" + e.StackTrace + "\n");
        }
        finally
        {
            reader.Close();
            stream.Close();
        }
    }

	public void Save()
    {
        string filename = "settings.snep";
        Debug.Log("saving " + filename + "...");
        FileStream stream = new FileStream(filename, FileMode.Create);
        try
        {
            DataContractSerializer serializer = new DataContractSerializer(typeof(OptionsMenu));
            serializer.WriteObject(stream, this);
            Debug.Log("done.");
        }
        catch (Exception e)
        {
            Debug.Log("save failed. " + e.Message);
            Debug.Log("Stacktrace:\n" + e.StackTrace + "\n");
        }
        finally
        { stream.Close(); }
		mainMenuButtons.ClickSound();
        mainMenuButtons.LoadSettings();
    }
}
