﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Death : MonoBehaviour
{
	float opacity = 0;
	public Image panel;

	void Start ()
	{
		
	}
	
	void Update ()
	{
		if (opacity < 1)
		{
			opacity += Time.deltaTime;
			panel.color = new Vector4(0,0,0,opacity);
		}
	}
}
