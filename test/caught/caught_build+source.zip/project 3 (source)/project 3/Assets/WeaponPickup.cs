﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponPickup : MonoBehaviour
{
    Transform myTransform;
    public float rotationSpeed = -60;
    public float bounceSpeed = 1f;
    public float bounceMinHeight = -0.6f;
    public float bounceMaxHeight = -0.4f;

    float currentPosition;
    int bounceDirection = 1;

    void Start()
    { myTransform = gameObject.transform; }

    void Update()
    {
        currentPosition += bounceSpeed * bounceDirection * Time.deltaTime;
        if (currentPosition >= 1)
        {
            currentPosition = 1;
            bounceDirection = -1;
        }
        else if (currentPosition <= 0)
        {
            currentPosition = 0;
            bounceDirection = 1;
        }
        myTransform.position = new Vector3(myTransform.position.x, Mathf.SmoothStep(bounceMinHeight, bounceMaxHeight, currentPosition), myTransform.position.z);
        myTransform.Rotate(new Vector3(0, rotationSpeed * Time.deltaTime, 0));
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name == "player")
        {
            PlayerController player = other.gameObject.GetComponent<PlayerController>() as PlayerController;
            int contains = -1;
            for (int i = player.weapons.Count - 1; i >= 0; i--)
            {
                if (player.weapons[i].name == gameObject.name || player.weapons[i].name + "(Clone)" == gameObject.name)
                { contains = i; }
            }

            if (contains >= 0)
            {
                player.weapons[contains].ammo += (gameObject.GetComponent<Gun>() as Gun).ammo;
                if (!player.weapons[contains].obtained)
                {
                    player.SetWeapon(contains);
                    player.weapons[contains].obtained = true;
                    player.PlayWeaponPickup();
                }
                else
                { player.PlayAmmoPickup(); }
            }

            Destroy(gameObject);
        }
    }
}
