﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Xml;
using System;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;

[DataContract]
public class Score : MonoBehaviour
{
	[DataMember]
	public float[] scores = new float[10];
    [DataMember]
    public string[] names = new string[10];
    public float TopScore
    {
        get
        { return scores[0]; }
    }
    public float BottomScore
    {
        get
        { return scores[9]; }
    }

	public Score()
	{ Load();   }

    public int ScorePosition(float score)
    {
        int index = -1;
        for (int i = scores.Length - 1; i >= 0; i--)
        {
            if (score > scores[i])
            { index = i; }
            else
            { break; }
        }
        return index;
    }

    public int AddScore(float score, string name)
    {
        int position = ScorePosition(score);
        if (position >= 0)
        {
            for (int i = scores.Length - 2; i >= position; i--)
            {
                scores[i+1] = scores[i];
                names[i+1]  = names[i];
            }
            scores[position] = score;
            names[position]  = name;
        }
        return position;
    }

	public void Load()
    {
		string filename = "highscore.scr";
        Debug.Log("loading " + filename + "...");
        if (File.Exists(filename))
        {
            FileStream stream = new FileStream(filename, FileMode.Open);
            XmlDictionaryReader reader = XmlDictionaryReader.CreateTextReader(stream, new XmlDictionaryReaderQuotas());
            try
            {
                DataContractSerializer serializer = new DataContractSerializer(typeof(Score));
                Score highscore = (Score)serializer.ReadObject(reader, true);
                scores = highscore.scores;
                names = highscore.names;
                Debug.Log("done.");
            }
            catch (Exception e)
            {
                Debug.Log("load failed. " + e.Message);
                Debug.Log("Stacktrace:\n" + e.StackTrace + "\n");
            }
            finally
            {
                reader.Close();
                stream.Close();
            }
        }
    }

	public void Save()
    {
		string filename = "highscore.scr";
        Debug.Log("saving " + filename + "...");
        FileStream stream = new FileStream(filename, FileMode.Create);
        try
        {
            DataContractSerializer serializer = new DataContractSerializer(typeof(Score));
            serializer.WriteObject(stream, this);
            Debug.Log("done.");
        }
        catch (Exception e)
        {
            Debug.Log("save failed. " + e.Message);
            Debug.Log("Stacktrace:\n" + e.StackTrace + "\n");
        }
        finally
        { stream.Close(); }
	}
}