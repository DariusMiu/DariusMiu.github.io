﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    public Rigidbody myBody;
    public Bullets bullets;
    public GameObject bullet;
    public float inputDrag = 25;
    public float normalDrag = 50;
    public new GameObject camera;
    public float forceModifier;
    public float rotateModifier;
    public List<Gun> weapons;
    public int currentWeapon = int.MaxValue;
    CursorLockMode wantedMode;
    public AudioSource source;
    public AudioClip ammo;
    public AudioClip swap;
    public AudioClip pistol;
    public AudioClip rifle;
    public AudioClip shotgun;
    public AudioClip weapon;
    public AudioClip noammo;
    public Text text;
    public Text pointsText;
    public GameObject newHighscoreName;
    public float points;
    public float Points
    {
        get
        { return points; }
        set
        {
            points = value; 
            pointsText.text = "points: " + points.ToString();
        }
    }
    public GameObject panel;
    public Text deathScore;
    bool dead = false;

    void Start ()
    {
        newHighscoreName.SetActive(false);
        OptionsMenu options = new OptionsMenu();
        options.Load();
        source = GetComponent<AudioSource>();
        source.volume = options.soundFX;
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }
	
	void Update ()
    {
        if (!dead)
        {
            Vector3 force = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
            if (force != Vector3.zero)
            { myBody.drag = inputDrag; }
            else
            { myBody.drag = normalDrag; }
            float rotationX = Input.GetAxis("Mouse X");
            float rotationY = -Input.GetAxis("Mouse Y");
            transform.Rotate(new Vector3(0, rotationX * rotateModifier * Time.deltaTime, 0));
            camera.transform.Rotate(new Vector3(rotationY * rotateModifier * Time.deltaTime, 0, 0));

            if (Input.GetButton("Sprint"))
            { myBody.AddRelativeForce(force.normalized * forceModifier * 2 * Time.deltaTime); }
            else
            { myBody.AddRelativeForce(force.normalized * forceModifier * Time.deltaTime); }

            //bullet.transform.position = weapons[currentWeapon].bulletSpawn.position;
            //bullet.transform.eulerAngles = new Vector3(90, 0, 0) + weapons[currentWeapon].transform.eulerAngles;


            if (currentWeapon < weapons.Count)
            {
                if (weapons[currentWeapon].automatic)
                {
                    if (Input.GetButton("Fire1"))
                    {
                        int shot = weapons[currentWeapon].Fire();
                        if (shot > 0)
                        {
                            CreateBullet(Random.insideUnitSphere * weapons[currentWeapon].spread);
                            PlayFireNoise();
                        }
                        else if (shot < 0)
                        { source.PlayOneShot(noammo, 1); }
                    }
                }
                else
                {
                    if (Input.GetButtonDown("Fire1"))
                    {
                        int shot = weapons[currentWeapon].Fire();
                        if (shot > 0)
                        {
                            CreateBullet(Random.insideUnitSphere * weapons[currentWeapon].spread);
                            PlayFireNoise();
                        }
                        else if (shot < 0)
                        { source.PlayOneShot(noammo, 1); }
                    }
                }
                text.text = weapons[currentWeapon].ammo.ToString();
            }

            for (int i = weapons.Count; i > 0; i--)
            {
                if (Input.GetKeyDown(i.ToString()) && weapons[i-1].obtained)
                { SetWeapon(i - 1); }
            }

            if (Input.GetKeyDown(KeyCode.Escape))
            { Cursor.lockState = CursorLockMode.None; }
        }
    }

    void CreateBullet(Vector3 tempRotation)
    {
        GameObject tempbullet = Instantiate(bullet);
        tempbullet.transform.position = weapons[currentWeapon].bulletSpawn.position;
        tempbullet.transform.eulerAngles = new Vector3(90, 0, 0) + weapons[currentWeapon].transform.eulerAngles + tempRotation;
        (tempbullet.GetComponent(typeof(Rigidbody)) as Rigidbody).velocity = (weapons[currentWeapon].transform.forward.normalized) * weapons[currentWeapon].bulletSpeed + tempRotation;
    }

    public void PlayFireNoise()
    {
        switch (currentWeapon)
        {
            case 0: // pistol
                source.PlayOneShot(pistol, 1);
                break;
            case 1: // rifle
                source.PlayOneShot(rifle, 1);
                break;
            case 2: // shotgun
                source.PlayOneShot(shotgun, 1);
                break;
        }
    }

    public void PlayWeaponPickup()
    { source.PlayOneShot(weapon, 1); }

    public void PlayAmmoPickup()
    { source.PlayOneShot(ammo, 1); }

    public void SetWeapon(int weapon)
    {
        if (weapon != currentWeapon)
        {
            if (currentWeapon < weapons.Count)
            { weapons[currentWeapon].gameObject.SetActive(false); }
            currentWeapon = weapon;
            weapons[currentWeapon].gameObject.SetActive(true);
            source.PlayOneShot(swap, 1);
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.gameObject.tag == "enemy" && !dead)
        {
            dead = true;
            Score score = new Score();
            if (points > score.BottomScore)
            {
                newHighscoreName.SetActive(true);
                deathScore.text = "new highscore: " + points.ToString();
            }
            else
            { deathScore.text = "score: " + points.ToString(); }
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            myBody.constraints = RigidbodyConstraints.FreezeAll;
            panel.SetActive(true);
        }
    }
}
