﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shotgun : Gun
{
    public uint pellets = 8;
    public PlayerController player;

    public override int Fire()
    {
        if (timeSinceLastShot <= 0)
        {
            timeSinceLastShot = fireRate;
            if (ammo > 0)
            {
                ammo--;
                for (int i = 0; i < pellets; i++)
                { CreateBullet(Random.insideUnitSphere * spread); }
                player.PlayFireNoise();
                return 0;
            }
            return -1;
        }
        return 0;
    }

    void CreateBullet(Vector3 tempRotation)
    {
        GameObject tempbullet = Instantiate(player.bullet);
        tempbullet.transform.position = bulletSpawn.position;
        tempbullet.transform.eulerAngles = new Vector3(90, 0, 0) + transform.eulerAngles + tempRotation;
        (tempbullet.GetComponent<Rigidbody>() as Rigidbody).velocity = (transform.forward.normalized) * bulletSpeed + tempRotation;
    }
}
