﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Leaderboard : MonoBehaviour
{
	public Text text;
	public Score scores;

	void Start ()
	{
		scores = new Score();
		string leadertext = scores.names[0] + ": " + scores.scores[0].ToString() + " :[1]";
		for (int i = 1; i < scores.scores.Length; i++)
		{
			if (scores.scores[i] > 0)
			{ leadertext = leadertext + "\n" + scores.names[i] + ":  " + scores.scores[i].ToString() + "  :[" + (i+1).ToString() + "]"; }
			else
			{ break; }
		}
		text.text = leadertext;
	}
}
