﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ill : Enemy
{
    void Start()
    {
        myTransform = gameObject.transform;
        playerTransform = GameObject.Find("chase").transform;
        player = GameObject.Find("player").GetComponent(typeof(PlayerController)) as PlayerController;
        agent = GetComponent<UnityEngine.AI.NavMeshAgent>() as UnityEngine.AI.NavMeshAgent;
        jenny = GameObject.Find("world controller").GetComponent(typeof(Jenny)) as Jenny;
    }
}
