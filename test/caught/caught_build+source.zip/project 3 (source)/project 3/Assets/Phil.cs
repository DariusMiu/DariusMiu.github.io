﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Phil : Enemy
{

    void Update()
    {
        Vector3 target = new Vector3(-playerTransform.position.x, playerTransform.position.y, -playerTransform.position.z);
        heading = target - myTransform.position;
        myBody.AddForce(heading.normalized * forceModifier * Time.deltaTime);
    }
}
