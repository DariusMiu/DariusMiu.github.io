﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Caught : MonoBehaviour
{
	public MainMenuButtons mainMenuButtons;
	public Text newHighscoreName;
	public PlayerController player;

	void Start ()
	{
		
	}

	public void Restart()
	{
		if (newHighscoreName.gameObject.activeSelf)
		{
			Score scores = new Score();
			scores.AddScore(player.points, newHighscoreName.text);
            scores.Save();
		}
		mainMenuButtons.StartGame();
	}

	public void LoadMainMenu()
	{
		if (newHighscoreName.gameObject.activeSelf)
		{
			Score scores = new Score();
			scores.AddScore(player.points, newHighscoreName.text);
            scores.Save();
		}
		mainMenuButtons.LoadMainMenu();
	}
}
