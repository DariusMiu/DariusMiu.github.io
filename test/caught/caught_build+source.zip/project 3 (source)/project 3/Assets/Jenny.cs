﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Jenny : MonoBehaviour
{
    public GameObject[] weapons;
    public GameObject[] enemies;
    public Collider[] collisionObjects;
    public int[] playArea = new int[4];
    public int weaponCount = 10;
    public int enemyCount = 10;
    public int currentEnemies = -1;
    System.Random RAND = new System.Random();
    public int wave = 0;
    public Text waveText;

    // Use this for initialization
    void Start()
    { NewWave(); }

    public void NewWave()
    {
        wave++;
        if (wave <= 5)
        {
            enemyCount = 9 + wave;
            weaponCount = 21 - wave;
        }
        else if (wave <= 10)
        {
            enemyCount = 5 + wave * 2;
            weaponCount = 21 - wave;
        }
        else //if (wave <= 25)
        {
            enemyCount = wave * 3;
            weaponCount = 10;
        }
        currentEnemies = enemyCount;
        
        waveText.text = "wave: " + wave.ToString();

        int bills = 0;
        
        for (int i = 0; i < weaponCount; i++)
        {
            Vector3 tempPosition;
            do
            {
                float X = Random.Range(playArea[0], playArea[1]);
                float Y = Random.Range(playArea[2], playArea[3]);
                tempPosition = new Vector3(X, 0.5f, Y);
            } while (!IsValidSpawnPosition(tempPosition));
            GameObject tempwep = Instantiate(weapons[RAND.Next(weapons.Length)]);
            tempwep.transform.position = tempPosition;
        }


        for (int i = 0; i < enemyCount; i++)
        {
            Vector3 tempPosition;
            do
            {
                float X = Random.Range(playArea[0], playArea[1]);
                float Y = Random.Range(playArea[2], playArea[3]);
                tempPosition = new Vector3(X, 0, Y);
            } while (!IsValidSpawnPosition(tempPosition));
            GameObject tempenemy = Instantiate(enemies[RAND.Next(enemies.Length)]);
            if (tempenemy.name == "bill" || tempenemy.name == "bill(Clone)")
            { bills++; }
            tempenemy.transform.position = tempPosition;
        }
        /*
        if (bills > 3)
        {
            PlayerController player = GameObject.Find("player").GetComponent<PlayerController>() as PlayerController;
            (player.bullet.GetComponent<Bullet>() as Bullet).damage = bills / 3f;
        }
        Debug.Log("Bills:" + bills);
        */
    }

    bool IsValidSpawnPosition(Vector3 Position)
    {
        for (int i = 0; i < collisionObjects.Length; i++)
        {
            if (collisionObjects[i].bounds.Contains(Position))
            { return false; }
        }
        return true;
    }
}
