﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuButtons : MonoBehaviour
{
	public AudioSource source;
	public AudioSource backgroundSource;
    public AudioClip click;
    public AudioClip hover;
    public AudioClip back;
	public OptionsMenu optionsController;
	public GameObject mainMenu;
	public GameObject introMenu;
	public GameObject optionsMenu;
	public GameObject credits;
	public GameObject leaderboard;

	void Start()
	{
		mainMenu.SetActive(true);
		optionsMenu.SetActive(false);
		introMenu.SetActive(false);
		credits.SetActive(false);
		leaderboard.SetActive(false);
		LoadSettings();
	}

	public void LoadSettings()
	{
        optionsController.Load();
		optionsController.soundFXslider.value = optionsController.soundFX;
		optionsController.musicSlider.value = optionsController.music;

        source.volume = optionsController.soundFX;
        backgroundSource.volume = optionsController.music;
	}

	public void StartGame()
	{
		source.PlayOneShot(click, 1);
		SceneManager.LoadScene("SampleScene");
	}

	public void LoadMainMenu()
	{
		source.PlayOneShot(click, 1);
		SceneManager.LoadScene("MainMenu");
	}
	
	public void Play()
	{
		source.PlayOneShot(click, 1);
		mainMenu.SetActive(false);
		optionsMenu.SetActive(false);
		introMenu.SetActive(true);
		credits.SetActive(false);
		leaderboard.SetActive(false);
	}

	public void LoadOptions()
	{
		ClickSound();
		mainMenu.SetActive(false);
		optionsMenu.SetActive(true);
		introMenu.SetActive(false);
		credits.SetActive(false);
		leaderboard.SetActive(false);
		LoadSettings();
	}

	public void LoadCredits()
	{
		ClickSound();
		mainMenu.SetActive(false);
		optionsMenu.SetActive(false);
		introMenu.SetActive(false);
		credits.SetActive(true);
		leaderboard.SetActive(false);
	}

	public void LoadLeaderboard()
	{
		ClickSound();
		mainMenu.SetActive(false);
		optionsMenu.SetActive(false);
		introMenu.SetActive(false);
		credits.SetActive(false);
		leaderboard.SetActive(true);
	}

	public void Quit()
	{
		BackSound();
		Application.Quit();
	}

	public void BackToMain()
	{
		BackSound();
		mainMenu.SetActive(true);
		optionsMenu.SetActive(false);
		introMenu.SetActive(false);
		credits.SetActive(false);
		leaderboard.SetActive(false);
	}

	public void ClickSound()
	{
		source.PlayOneShot(click, 1);
	}

	public void BackSound()
	{
		source.PlayOneShot(back, 1);
	}

	public void HoverSound()
	{
		source.PlayOneShot(hover, 1);
	}
}
